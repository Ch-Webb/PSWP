import matplotlib.pyplot as plt
import numpy as np
from simulationsource import *
resultsdict = {
    "Alice" : 0,
    "Bob": 0,
    "Clare": 0,
    "Dennis": 0,
    "Eva": 0,
    }
for x in range(0, 20):
    alice = 0
    bob = 0
    clare = 0
    dennis = 0
    eva = 0
    for x in range(0, 200):
        for i in range(0, 6):
            simulate = calculate_finishing_order(generate_performances(read_sailor_data('sailordata.csv')))
        for item in simulate:
            #Returning index but as arrays start at 0 index will be 1 less than finishing position - add 1 to account
            results[item].append((simulate.index(item) + 1))
        #Seriesinput acts as an intermediary, allowing names and results to be linked 
        seriesinput = []
        finaloutput = []
        for key in results:
            scorein = (key, results[key])
            seriesinput.append(scorein)
        sortedseries = sort_series(seriesinput, 0)
        for item in sortedseries:
            finaloutput.append(item[0])
        resultsdict[finaloutput[0]] += 1

labels = "Alice", "Bob", "Clare"
sizes = [resultsdict["Alice"], resultsdict["Bob"], resultsdict["Clare"]]
explode = (0, 0.2, 0)
ax1 = plt.subplot()
ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%', shadow=True, startangle=90)
ax1.axis('equal')

plt.show()
        
